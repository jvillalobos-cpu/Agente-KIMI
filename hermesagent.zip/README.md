# HERMES Intelligence Unit — Kimi AI Agent for Raspberry Pi

A lightweight, resilient async AI agent that runs on a Raspberry Pi inside a
HERMES unit, using the Kimi AI (Moonshot AI) OpenAI-compatible API for
reasoning and calling local hardware functions (GPIO, serial, system
telemetry) as tools.

## Project layout

```
hermes_agent/
  config.py             # pydantic-settings configuration (env vars / .env)
  kimi_client.py         # async Kimi AI client: streaming + retry/backoff
  hardware_interface.py  # GPIO/serial/system-metrics, with a simulated fallback
  tools.py                # JSON tool schemas exposed to Kimi AI
  memory.py               # SQLite-backed sliding-window conversation memory
  agent_core.py            # event loop, tool router, conversation orchestration
  main.py                   # entry point (asyncio + systemd-friendly)
systemd/hermes-agent.service
scripts/install.sh
tests/
```

## Quick start (development, any machine)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
pip install -e .

cp .env.example .env   # fill in KIMI_API_KEY and HERMES_ID
pytest -q

python -m hermes_agent.main   # interactive: type messages on stdin
```

Off a real Raspberry Pi, `hardware_interface.py` automatically falls back to
a simulated backend (or set `HARDWARE_SIMULATE=true` to force it), so the
full agent loop and Kimi AI integration can be developed and tested without
physical hardware.

## Raspberry Pi deployment

```bash
git clone <this-repo> /tmp/hermes-agent-src
cd /tmp/hermes-agent-src
sudo bash scripts/install.sh
sudo nano /etc/hermes-agent/hermes-agent.env   # set KIMI_API_KEY, HERMES_ID
sudo systemctl start hermes-agent
sudo journalctl -u hermes-agent -f
```

This installs to `/opt/hermes-agent`, creates a dedicated `hermes` system
user (in the `gpio`/`dialout` groups for hardware access), sets up a Python
virtualenv with `requirements.txt` + `requirements-hardware.txt` (GPIO/serial
libs, only installed on ARM), and registers `hermes-agent.service` to start
on boot with automatic restart on failure.

## Configuration

All configuration is via environment variables (see `.env.example`),
validated strictly at startup with `pydantic-settings`. Required:
`KIMI_API_KEY`, `HERMES_ID`. Everything else has sane defaults.

## Resilience notes

- **Network loss**: `KimiClient` retries with exponential backoff + jitter
  (`KIMI_MAX_RETRIES`, capped by `KIMI_BACKOFF_MAX`). If retries are
  exhausted, the agent returns a degraded local-status response instead of
  crashing, and keeps its hardware tick loop running.
- **Memory footprint**: conversation history is persisted to SQLite and only
  a bounded sliding window (`HISTORY_WINDOW_MESSAGES` messages,
  `HISTORY_MAX_CHARS` characters) is ever loaded into a prompt.
- **Process crashes**: the systemd unit restarts on failure with a start-rate
  limit, and `MemoryMax`/`CPUQuota` keep the agent within the Pi's resource
  budget.
