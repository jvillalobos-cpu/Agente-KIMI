from __future__ import annotations

import json

import httpx
import pytest

from hermes_agent.config import Settings
from hermes_agent.kimi_client import KimiAPIError, KimiClient, KimiConnectionError


def _sse(*events: dict) -> bytes:
    body = ""
    for e in events:
        body += f"data: {json.dumps(e)}\n\n"
    body += "data: [DONE]\n\n"
    return body.encode()


@pytest.mark.asyncio
async def test_chat_success(settings: Settings):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"choices": [{"message": {"content": "hi"}}]})

    transport = httpx.MockTransport(handler)
    client = KimiClient(settings)
    client._client = httpx.AsyncClient(transport=transport, base_url=settings.kimi_base_url)
    try:
        result = await client.chat([{"role": "user", "content": "hello"}])
        assert result["choices"][0]["message"]["content"] == "hi"
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_chat_retries_then_succeeds(settings: Settings):
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] == 1:
            return httpx.Response(503, text="try again")
        return httpx.Response(200, json={"choices": [{"message": {"content": "ok"}}]})

    transport = httpx.MockTransport(handler)
    client = KimiClient(settings)
    client._client = httpx.AsyncClient(transport=transport, base_url=settings.kimi_base_url)
    try:
        result = await client.chat([{"role": "user", "content": "hello"}])
        assert calls["n"] == 2
        assert result["choices"][0]["message"]["content"] == "ok"
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_chat_exhausts_retries(settings: Settings):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(503, text="down")

    transport = httpx.MockTransport(handler)
    client = KimiClient(settings)
    client._client = httpx.AsyncClient(transport=transport, base_url=settings.kimi_base_url)
    try:
        with pytest.raises(KimiConnectionError):
            await client.chat([{"role": "user", "content": "hello"}])
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_chat_non_retryable_error_raises_api_error(settings: Settings):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, text="unauthorized")

    transport = httpx.MockTransport(handler)
    client = KimiClient(settings)
    client._client = httpx.AsyncClient(transport=transport, base_url=settings.kimi_base_url)
    try:
        with pytest.raises(KimiAPIError):
            await client.chat([{"role": "user", "content": "hello"}])
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_stream_chat_collecting_aggregates_text_and_tools(settings: Settings):
    events = [
        {"choices": [{"delta": {"content": "Hel"}}]},
        {"choices": [{"delta": {"content": "lo"}}]},
        {
            "choices": [
                {
                    "delta": {
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": "call_1",
                                "function": {"name": "get_system", "arguments": ""},
                            }
                        ]
                    }
                }
            ]
        },
        {
            "choices": [
                {
                    "delta": {
                        "tool_calls": [
                            {"index": 0, "function": {"arguments": '{"a":'}}
                        ]
                    }
                }
            ]
        },
        {
            "choices": [
                {
                    "delta": {"tool_calls": [{"index": 0, "function": {"arguments": "1}"}}]},
                    "finish_reason": "tool_calls",
                }
            ]
        },
    ]

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=_sse(*events), headers={"content-type": "text/event-stream"})

    transport = httpx.MockTransport(handler)
    client = KimiClient(settings)
    client._client = httpx.AsyncClient(transport=transport, base_url=settings.kimi_base_url)
    try:
        result = await client.stream_chat_collecting([{"role": "user", "content": "hi"}])
        assert result.content == "Hello"
        assert result.finish_reason == "tool_calls"
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["function"]["name"] == "get_system"
        assert result.tool_calls[0]["function"]["arguments"] == '{"a":1}'
    finally:
        await client.aclose()
