from __future__ import annotations

import os
from pathlib import Path

import pytest

from hermes_agent.config import Settings


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    os.environ.pop("KIMI_API_KEY", None)
    return Settings(
        kimi_api_key="test-key",
        hermes_id="test-unit",
        data_dir=tmp_path / "data",
        conversation_db=tmp_path / "data" / "conv.sqlite3",
        log_dir=tmp_path / "log",
        hardware_simulate=True,
        kimi_max_retries=1,
        kimi_backoff_base=0.01,
        kimi_backoff_max=0.02,
    )
