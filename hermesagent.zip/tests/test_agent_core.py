from __future__ import annotations

import json

import pytest

from hermes_agent.agent_core import HermesAgent
from hermes_agent.config import Settings
from hermes_agent.hardware_interface import HardwareInterface
from hermes_agent.kimi_client import KimiConnectionError, StreamResult
from hermes_agent.memory import ConversationMemory


class FakeKimiClient:
    """Scripted stand-in for KimiClient.stream_chat_collecting."""

    def __init__(self, results: list[StreamResult] | Exception):
        self._results = results
        self._i = 0

    async def stream_chat_collecting(self, messages, tools=None, temperature=0.3, on_delta=None):
        if isinstance(self._results, Exception):
            raise self._results
        result = self._results[self._i]
        self._i += 1
        return result


@pytest.fixture
def hardware(settings: Settings):
    hw = HardwareInterface(settings)
    yield hw
    hw.shutdown()


@pytest.fixture
def memory(settings: Settings):
    mem = ConversationMemory(
        settings.conversation_db, settings.history_window_messages, settings.history_max_chars
    )
    yield mem
    mem.close()


@pytest.mark.asyncio
async def test_handle_user_message_simple_reply(settings, hardware, memory):
    fake = FakeKimiClient([StreamResult(content="Hello human", finish_reason="stop")])
    agent = HermesAgent(settings, fake, hardware, memory)

    reply = await agent.handle_user_message("hi")

    assert reply == "Hello human"
    assert agent.network_degraded is False
    messages = memory.recent_messages()
    assert messages[-1]["role"] == "assistant"
    assert messages[-1]["content"] == "Hello human"


@pytest.mark.asyncio
async def test_handle_user_message_executes_tool_call(settings, hardware, memory):
    tool_call = {
        "id": "call_1",
        "type": "function",
        "function": {"name": "get_system_health", "arguments": "{}"},
    }
    fake = FakeKimiClient(
        [
            StreamResult(tool_calls=[tool_call], finish_reason="tool_calls"),
            StreamResult(content="System looks fine.", finish_reason="stop"),
        ]
    )
    agent = HermesAgent(settings, fake, hardware, memory)

    reply = await agent.handle_user_message("how's the system?")

    assert reply == "System looks fine."
    messages = memory.recent_messages()
    tool_msgs = [m for m in messages if m["role"] == "tool"]
    assert len(tool_msgs) == 1
    payload = json.loads(tool_msgs[0]["content"])
    assert "cpu_percent" in payload


@pytest.mark.asyncio
async def test_handle_user_message_degrades_on_network_failure(settings, hardware, memory):
    fake = FakeKimiClient(KimiConnectionError("no network"))
    agent = HermesAgent(settings, fake, hardware, memory)

    reply = await agent.handle_user_message("hi")

    assert "can't reach Kimi AI" in reply
    assert agent.network_degraded is True


@pytest.mark.asyncio
async def test_handle_user_message_unknown_tool_reports_error(settings, hardware, memory):
    tool_call = {
        "id": "call_1",
        "type": "function",
        "function": {"name": "does_not_exist", "arguments": "{}"},
    }
    fake = FakeKimiClient(
        [
            StreamResult(tool_calls=[tool_call], finish_reason="tool_calls"),
            StreamResult(content="Sorry, that tool isn't available.", finish_reason="stop"),
        ]
    )
    agent = HermesAgent(settings, fake, hardware, memory)

    reply = await agent.handle_user_message("do the impossible thing")

    assert reply == "Sorry, that tool isn't available."
    messages = memory.recent_messages()
    tool_msgs = [m for m in messages if m["role"] == "tool"]
    payload = json.loads(tool_msgs[0]["content"])
    assert "error" in payload
