from __future__ import annotations

from pathlib import Path

from hermes_agent.memory import ConversationMemory


def test_append_and_recent_messages(tmp_path: Path):
    mem = ConversationMemory(tmp_path / "conv.sqlite3", window_messages=10, max_chars=10_000)
    try:
        mem.append("user", "hello")
        mem.append("assistant", "hi there")
        messages = mem.recent_messages()
        assert [m["role"] for m in messages] == ["user", "assistant"]
        assert messages[0]["content"] == "hello"
    finally:
        mem.close()


def test_sliding_window_prunes_old_messages(tmp_path: Path):
    mem = ConversationMemory(tmp_path / "conv.sqlite3", window_messages=3, max_chars=10_000)
    try:
        for i in range(10):
            mem.append("user", f"msg-{i}")
        messages = mem.recent_messages()
        assert len(messages) == 3
        assert messages[-1]["content"] == "msg-9"
    finally:
        mem.close()


def test_char_budget_truncates_oldest(tmp_path: Path):
    mem = ConversationMemory(tmp_path / "conv.sqlite3", window_messages=10, max_chars=15)
    try:
        mem.append("user", "a" * 10)
        mem.append("user", "b" * 10)
        messages = mem.recent_messages()
        # Only the most recent message fits within the char budget.
        assert len(messages) == 1
        assert messages[0]["content"] == "b" * 10
    finally:
        mem.close()


def test_tool_call_round_trip(tmp_path: Path):
    mem = ConversationMemory(tmp_path / "conv.sqlite3", window_messages=10, max_chars=10_000)
    try:
        tool_calls = [{"id": "call_1", "type": "function", "function": {"name": "f", "arguments": "{}"}}]
        mem.append("assistant", None, tool_calls=tool_calls)
        mem.append("tool", '{"ok": true}', tool_call_id="call_1")
        messages = mem.recent_messages()
        assert messages[0]["tool_calls"] == tool_calls
        assert messages[1]["tool_call_id"] == "call_1"
    finally:
        mem.close()
