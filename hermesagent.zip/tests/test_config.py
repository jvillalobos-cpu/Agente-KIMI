from __future__ import annotations

import pytest
from pydantic import ValidationError

from hermes_agent.config import Settings


def test_settings_requires_api_key_and_hermes_id():
    with pytest.raises(ValidationError):
        Settings()  # type: ignore[call-arg]


def test_settings_defaults(settings: Settings):
    assert settings.kimi_base_url == "https://api.moonshot.cn/v1"
    assert settings.log_level == "INFO"
    assert settings.hardware_simulate is True


def test_settings_rejects_bad_log_level(tmp_path):
    with pytest.raises(ValidationError):
        Settings(
            kimi_api_key="k",
            hermes_id="u",
            log_level="NOT_A_LEVEL",
            data_dir=tmp_path,
        )


def test_ensure_directories_creates_paths(settings: Settings):
    settings.ensure_directories()
    assert settings.data_dir.exists()
    assert settings.conversation_db.parent.exists()
    assert settings.log_dir.exists()
