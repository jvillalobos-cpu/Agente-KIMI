from __future__ import annotations

import pytest

from hermes_agent.config import Settings
from hermes_agent.hardware_interface import HardwareError, HardwareInterface


@pytest.mark.asyncio
async def test_get_system_health_simulated(settings: Settings):
    hw = HardwareInterface(settings)
    try:
        health = await hw.get_system_health()
        assert health["simulated"] is True
        assert "cpu_percent" in health
        assert "ram_used_mb" in health
    finally:
        hw.shutdown()


@pytest.mark.asyncio
async def test_trigger_output_and_read_back(settings: Settings):
    hw = HardwareInterface(settings)
    try:
        result = await hw.trigger_output("status_led", True)
        assert result["state"] is True

        telemetry = await hw.read_telemetry("status_led")
        assert telemetry["on"] is True

        result_off = await hw.trigger_output("status_led", False)
        assert result_off["state"] is False
    finally:
        hw.shutdown()


@pytest.mark.asyncio
async def test_trigger_output_rejects_unknown(settings: Settings):
    hw = HardwareInterface(settings)
    try:
        with pytest.raises(HardwareError):
            await hw.trigger_output("nonexistent", True)
    finally:
        hw.shutdown()


@pytest.mark.asyncio
async def test_read_telemetry_rejects_unknown_channel(settings: Settings):
    hw = HardwareInterface(settings)
    try:
        with pytest.raises(HardwareError):
            await hw.read_telemetry("nonexistent")
    finally:
        hw.shutdown()


@pytest.mark.asyncio
async def test_serial_write_read_simulated(settings: Settings):
    hw = HardwareInterface(settings)
    try:
        write_result = await hw.serial_write("hello")
        assert write_result["bytes_written"] == 5

        read_result = await hw.serial_read(timeout_seconds=0.1)
        assert "line" in read_result
    finally:
        hw.shutdown()
