#!/usr/bin/env bash
# Install the HERMES agent as a systemd service on Raspberry Pi OS.
# Run as root: sudo bash scripts/install.sh
set -euo pipefail

INSTALL_DIR="/opt/hermes-agent"
CONFIG_DIR="/etc/hermes-agent"
DATA_DIR="/var/lib/hermes-agent"
LOG_DIR="/var/log/hermes-agent"
SERVICE_USER="hermes"

if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root (sudo)." >&2
  exit 1
fi

if ! id "$SERVICE_USER" &>/dev/null; then
  useradd --system --home-dir "$INSTALL_DIR" --shell /usr/sbin/nologin \
    --groups gpio,dialout "$SERVICE_USER"
fi

mkdir -p "$INSTALL_DIR" "$CONFIG_DIR" "$DATA_DIR" "$LOG_DIR"
rsync -a --exclude '.git' --exclude '.venv' --exclude '__pycache__' ./ "$INSTALL_DIR"/

if [[ ! -d "$INSTALL_DIR/venv" ]]; then
  python3 -m venv "$INSTALL_DIR/venv"
fi
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip
"$INSTALL_DIR/venv/bin/pip" install -r "$INSTALL_DIR/requirements.txt"
if [[ "$(uname -m)" == "aarch64" || "$(uname -m)" == "armv7l" ]]; then
  "$INSTALL_DIR/venv/bin/pip" install -r "$INSTALL_DIR/requirements-hardware.txt"
fi

if [[ ! -f "$CONFIG_DIR/hermes-agent.env" ]]; then
  cp "$INSTALL_DIR/.env.example" "$CONFIG_DIR/hermes-agent.env"
  echo "Wrote default config to $CONFIG_DIR/hermes-agent.env -- edit it with your KIMI_API_KEY."
fi

chown -R "$SERVICE_USER":"$SERVICE_USER" "$INSTALL_DIR" "$DATA_DIR" "$LOG_DIR"
chown root:"$SERVICE_USER" "$CONFIG_DIR/hermes-agent.env"
chmod 640 "$CONFIG_DIR/hermes-agent.env"

cp "$INSTALL_DIR/systemd/hermes-agent.service" /etc/systemd/system/hermes-agent.service
systemctl daemon-reload
systemctl enable hermes-agent.service

echo "Install complete. Edit $CONFIG_DIR/hermes-agent.env then run:"
echo "  sudo systemctl start hermes-agent"
echo "  sudo journalctl -u hermes-agent -f"
