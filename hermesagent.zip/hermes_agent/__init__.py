"""HERMES Intelligence Unit: a Kimi AI (Moonshot AI) agent for Raspberry Pi."""

__version__ = "0.1.0"
