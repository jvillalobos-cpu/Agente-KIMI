"""Async client for the Kimi AI (Moonshot AI) OpenAI-compatible chat API.

Designed for embedded, intermittently-connected HERMES units: every request
is wrapped in exponential-backoff retry logic, streaming responses are
consumed incrementally to minimize memory footprint and latency, and tool
(function) calls are assembled incrementally from streamed deltas.
"""

from __future__ import annotations

import asyncio
import json
import random
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

import httpx
from loguru import logger

from hermes_agent.config import Settings


class KimiAPIError(RuntimeError):
    """Raised when the Kimi API returns a non-retryable error."""


class KimiConnectionError(RuntimeError):
    """Raised when all retry attempts to reach Kimi AI have been exhausted."""


@dataclass
class ToolCallDelta:
    """Accumulator for a single streamed tool call."""

    id: str = ""
    name: str = ""
    arguments: str = ""


@dataclass
class StreamResult:
    """Final aggregated result of a streamed chat completion."""

    content: str = ""
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    finish_reason: str | None = None


# Errors worth retrying: connection issues and 5xx / 429 responses.
_RETRYABLE_STATUS_CODES = {408, 425, 429, 500, 502, 503, 504}


class KimiClient:
    """Async wrapper around the Kimi AI chat completions endpoint."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._client = httpx.AsyncClient(
            base_url=settings.kimi_base_url,
            timeout=httpx.Timeout(settings.kimi_request_timeout),
            headers={
                "Authorization": f"Bearer {settings.kimi_api_key.get_secret_value()}",
                "Content-Type": "application/json",
            },
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "KimiClient":
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.aclose()

    async def _backoff_sleep(self, attempt: int) -> None:
        base = self._settings.kimi_backoff_base
        cap = self._settings.kimi_backoff_max
        delay = min(cap, base * (2**attempt))
        delay = delay * (0.5 + random.random())  # jitter
        logger.warning("Kimi AI request retry in {:.2f}s (attempt {})", delay, attempt + 1)
        await asyncio.sleep(delay)

    async def stream_chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
    ) -> AsyncIterator[str] | StreamResult:
        """Stream a chat completion, yielding text chunks as they arrive.

        Returns an async generator; after full consumption, the aggregated
        StreamResult (content + tool calls) is available via `get_result()`
        on the generator wrapper returned by `stream_chat_collecting`.
        Use `stream_chat_collecting` for the common case where you need both
        the live text stream and the final structured result.
        """
        async for chunk in self._stream_raw(messages, tools, temperature):
            yield chunk

    async def stream_chat_collecting(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
        on_delta: Any = None,
    ) -> StreamResult:
        """Stream a chat completion and return the fully aggregated result.

        `on_delta`, if provided, is an (async or sync) callable invoked with
        each incremental text delta as it arrives -- useful for pushing text
        to an embedded display or log line without buffering the whole reply.
        """
        result = StreamResult()
        tool_deltas: dict[int, ToolCallDelta] = {}

        payload = self._build_payload(messages, tools, temperature, stream=True)
        async for event in self._post_stream_with_retry(payload):
            for choice in event.get("choices", []):
                delta = choice.get("delta", {})
                finish_reason = choice.get("finish_reason")
                if finish_reason:
                    result.finish_reason = finish_reason

                content_piece = delta.get("content")
                if content_piece:
                    result.content += content_piece
                    if on_delta is not None:
                        maybe_awaitable = on_delta(content_piece)
                        if asyncio.iscoroutine(maybe_awaitable):
                            await maybe_awaitable

                for tc in delta.get("tool_calls", []) or []:
                    idx = tc.get("index", 0)
                    acc = tool_deltas.setdefault(idx, ToolCallDelta())
                    if tc.get("id"):
                        acc.id = tc["id"]
                    fn = tc.get("function", {})
                    if fn.get("name"):
                        acc.name += fn["name"]
                    if fn.get("arguments"):
                        acc.arguments += fn["arguments"]

        for idx in sorted(tool_deltas):
            acc = tool_deltas[idx]
            result.tool_calls.append(
                {
                    "id": acc.id or f"call_{idx}",
                    "type": "function",
                    "function": {"name": acc.name, "arguments": acc.arguments},
                }
            )
        return result

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """Non-streaming chat completion, retried with exponential backoff."""
        payload = self._build_payload(messages, tools, temperature, stream=False)
        return await self._post_with_retry(payload)

    def _build_payload(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        temperature: float,
        stream: bool,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self._settings.kimi_model,
            "messages": messages,
            "temperature": temperature,
            "stream": stream,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        return payload

    async def _post_with_retry(self, payload: dict[str, Any]) -> dict[str, Any]:
        last_exc: Exception | None = None
        for attempt in range(self._settings.kimi_max_retries + 1):
            try:
                resp = await self._client.post("/chat/completions", json=payload)
                if resp.status_code in _RETRYABLE_STATUS_CODES:
                    raise KimiConnectionError(f"Retryable status {resp.status_code}: {resp.text}")
                resp.raise_for_status()
                return resp.json()
            except (httpx.TransportError, KimiConnectionError) as exc:
                last_exc = exc
                logger.warning("Kimi AI request failed: {}", exc)
                if attempt < self._settings.kimi_max_retries:
                    await self._backoff_sleep(attempt)
                    continue
                raise KimiConnectionError(
                    f"Exhausted retries contacting Kimi AI: {exc}"
                ) from exc
            except httpx.HTTPStatusError as exc:
                raise KimiAPIError(
                    f"Kimi AI returned {exc.response.status_code}: {exc.response.text}"
                ) from exc
        raise KimiConnectionError(f"Exhausted retries contacting Kimi AI: {last_exc}")

    async def _stream_raw(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        temperature: float,
    ) -> AsyncIterator[str]:
        payload = self._build_payload(messages, tools, temperature, stream=True)
        async for event in self._post_stream_with_retry(payload):
            for choice in event.get("choices", []):
                piece = choice.get("delta", {}).get("content")
                if piece:
                    yield piece

    async def _post_stream_with_retry(
        self, payload: dict[str, Any]
    ) -> AsyncIterator[dict[str, Any]]:
        for attempt in range(self._settings.kimi_max_retries + 1):
            try:
                async with self._client.stream(
                    "POST", "/chat/completions", json=payload
                ) as resp:
                    if resp.status_code in _RETRYABLE_STATUS_CODES:
                        body = await resp.aread()
                        raise KimiConnectionError(
                            f"Retryable status {resp.status_code}: {body!r}"
                        )
                    resp.raise_for_status()
                    async for line in resp.aiter_lines():
                        if not line or not line.startswith("data:"):
                            continue
                        data = line[len("data:") :].strip()
                        if data == "[DONE]":
                            return
                        try:
                            yield json.loads(data)
                        except json.JSONDecodeError:
                            logger.debug("Skipping malformed SSE chunk: {!r}", data)
                return
            except (httpx.TransportError, KimiConnectionError) as exc:
                logger.warning("Kimi AI stream failed: {}", exc)
                if attempt < self._settings.kimi_max_retries:
                    await self._backoff_sleep(attempt)
                    continue
                raise KimiConnectionError(
                    f"Exhausted retries contacting Kimi AI stream: {exc}"
                ) from exc
            except httpx.HTTPStatusError as exc:
                raise KimiAPIError(
                    f"Kimi AI returned {exc.response.status_code}: {exc.response.text}"
                ) from exc
