"""Single entry point: wires up config, hardware, memory, Kimi client, and the agent loop.

Intended to run as a systemd service (see systemd/hermes-agent.service) but
also works interactively from a terminal for development on a Pi or a dev
machine.
"""

from __future__ import annotations

import asyncio
import signal
import sys
from typing import NoReturn

from loguru import logger

from hermes_agent.agent_core import HermesAgent
from hermes_agent.config import Settings, get_settings
from hermes_agent.hardware_interface import HardwareInterface
from hermes_agent.kimi_client import KimiClient
from hermes_agent.memory import ConversationMemory


def configure_logging(settings: Settings) -> None:
    logger.remove()
    logger.add(sys.stderr, level=settings.log_level, enqueue=True, backtrace=False)
    try:
        settings.ensure_directories()
        logger.add(
            settings.log_dir / "hermes-agent.log",
            level=settings.log_level,
            rotation="10 MB",
            retention="14 days",
            compression="zip",
            enqueue=True,
            backtrace=False,
        )
    except OSError as exc:
        logger.warning("Could not set up file logging at {}: {}", settings.log_dir, exc)


async def _read_stdin_lines(queue: "asyncio.Queue[str]") -> None:
    """Bridge blocking stdin reads into the async input queue (interactive/dev mode)."""
    loop = asyncio.get_running_loop()
    while True:
        line = await loop.run_in_executor(None, sys.stdin.readline)
        if not line:
            await asyncio.sleep(0.5)
            continue
        text = line.strip()
        if text:
            await queue.put(text)


async def async_main() -> NoReturn:
    settings = get_settings()
    configure_logging(settings)
    settings.ensure_directories()

    logger.info("Starting HERMES Intelligence Unit '{}'", settings.hermes_id)

    hardware = HardwareInterface(settings)
    memory = ConversationMemory(
        settings.conversation_db, settings.history_window_messages, settings.history_max_chars
    )

    input_queue: "asyncio.Queue[str]" = asyncio.Queue()
    stop_event = asyncio.Event()

    def _handle_signal(sig: signal.Signals) -> None:
        logger.info("Received signal {}, shutting down gracefully", sig.name)
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, _handle_signal, sig)

    async with KimiClient(settings) as kimi_client:
        agent = HermesAgent(settings, kimi_client, hardware, memory)

        tasks = [
            asyncio.create_task(agent.run_forever(input_queue), name="agent-loop"),
            asyncio.create_task(_read_stdin_lines(input_queue), name="stdin-bridge"),
        ]

        try:
            await stop_event.wait()
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            memory.close()
            hardware.shutdown()
            logger.info("HERMES Intelligence Unit '{}' stopped.", settings.hermes_id)

    sys.exit(0)


def main() -> None:
    try:
        asyncio.run(async_main())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
