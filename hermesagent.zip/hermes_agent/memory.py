"""Lightweight, persistent sliding-window conversation memory.

Backed by SQLite so the RAM footprint stays constant regardless of how long
the HERMES unit has been running -- only the most recent window of messages
is pulled into memory when building a prompt, and the full history remains
on disk for later inspection/debugging.
"""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any

_SCHEMA = """
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL,
    content TEXT,
    tool_call_id TEXT,
    tool_calls TEXT,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
"""


class ConversationMemory:
    """Sliding-window conversation history persisted to SQLite (JSONL-compatible export)."""

    def __init__(self, db_path: Path, window_messages: int, max_chars: int) -> None:
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()
        self._window_messages = window_messages
        self._max_chars = max_chars

    def close(self) -> None:
        self._conn.close()

    def append(
        self,
        role: str,
        content: str | None,
        tool_call_id: str | None = None,
        tool_calls: list[dict[str, Any]] | None = None,
    ) -> None:
        self._conn.execute(
            "INSERT INTO messages (role, content, tool_call_id, tool_calls, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                role,
                content,
                tool_call_id,
                json.dumps(tool_calls) if tool_calls else None,
                time.time(),
            ),
        )
        self._conn.commit()
        self._prune()

    def _prune(self) -> None:
        """Keep only the most recent `window_messages` rows to bound growth."""
        self._conn.execute(
            "DELETE FROM messages WHERE id NOT IN ("
            "  SELECT id FROM messages ORDER BY id DESC LIMIT ?"
            ")",
            (self._window_messages,),
        )
        self._conn.commit()

    def recent_messages(self) -> list[dict[str, Any]]:
        """Return the sliding window as OpenAI/Kimi chat-message dicts, oldest first.

        Applies both a message-count window and a total character budget so
        an unusually verbose exchange cannot blow the model's context.
        """
        rows = self._conn.execute(
            "SELECT role, content, tool_call_id, tool_calls FROM messages "
            "ORDER BY id DESC LIMIT ?",
            (self._window_messages,),
        ).fetchall()

        messages: list[dict[str, Any]] = []
        total_chars = 0
        for role, content, tool_call_id, tool_calls_json in rows:
            piece_chars = len(content or "")
            if total_chars + piece_chars > self._max_chars and messages:
                break
            total_chars += piece_chars
            msg: dict[str, Any] = {"role": role, "content": content}
            if tool_call_id:
                msg["tool_call_id"] = tool_call_id
            if tool_calls_json:
                msg["tool_calls"] = json.loads(tool_calls_json)
            messages.append(msg)

        messages.reverse()
        return messages

    def export_jsonl(self, path: Path) -> None:
        """Export the full stored history (not just the window) as JSONL for backup/debugging."""
        rows = self._conn.execute(
            "SELECT role, content, tool_call_id, tool_calls, created_at FROM messages ORDER BY id ASC"
        ).fetchall()
        with open(path, "w", encoding="utf-8") as f:
            for role, content, tool_call_id, tool_calls_json, created_at in rows:
                record = {
                    "role": role,
                    "content": content,
                    "tool_call_id": tool_call_id,
                    "tool_calls": json.loads(tool_calls_json) if tool_calls_json else None,
                    "created_at": created_at,
                }
                f.write(json.dumps(record) + "\n")
