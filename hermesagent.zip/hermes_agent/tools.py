"""JSON Schemas for Kimi AI function/tool calling, mapped to HardwareInterface methods.

Kept separate from `hardware_interface.py` so the wire-format contract with
Kimi AI can evolve independently from the hardware implementation.
"""

from __future__ import annotations

TOOL_SCHEMAS: list[dict[str, object]] = [
    {
        "type": "function",
        "function": {
            "name": "get_system_health",
            "description": (
                "Get current HERMES unit system health: CPU load percent, CPU "
                "temperature in Celsius, RAM usage, free disk space, and uptime."
            ),
            "parameters": {
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_telemetry",
            "description": (
                "Read a named telemetry channel from the HERMES unit: the physical "
                "'button' input, or the current on/off state of 'status_led', "
                "'alert_led', or 'relay_output'."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "channel": {
                        "type": "string",
                        "enum": ["button", "status_led", "alert_led", "relay_output"],
                        "description": "Which telemetry channel to read.",
                    }
                },
                "required": ["channel"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "trigger_output",
            "description": "Turn a HERMES digital output on or off.",
            "parameters": {
                "type": "object",
                "properties": {
                    "output": {
                        "type": "string",
                        "enum": ["status_led", "alert_led", "relay_output"],
                        "description": "Which output to set.",
                    },
                    "state": {
                        "type": "boolean",
                        "description": "True to turn on, false to turn off.",
                    },
                },
                "required": ["output", "state"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "serial_write",
            "description": "Write a line of text to the HERMES unit's serial peripheral (e.g. an external sensor board).",
            "parameters": {
                "type": "object",
                "properties": {
                    "data": {"type": "string", "description": "Text to write, without trailing newline."}
                },
                "required": ["data"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "serial_read",
            "description": "Read one line of text from the HERMES unit's serial peripheral, with a timeout.",
            "parameters": {
                "type": "object",
                "properties": {
                    "timeout_seconds": {
                        "type": "number",
                        "description": "Maximum seconds to wait for a line. Defaults to 1.0.",
                        "minimum": 0.1,
                        "maximum": 30.0,
                    }
                },
                "additionalProperties": False,
            },
        },
    },
]

# Name -> minimal JSON-schema-implied kwarg allowlist, used for defensive
# argument filtering before dispatch (see agent_core.ToolRouter).
TOOL_NAMES: frozenset[str] = frozenset(schema["function"]["name"] for schema in TOOL_SCHEMAS)  # type: ignore[index]
