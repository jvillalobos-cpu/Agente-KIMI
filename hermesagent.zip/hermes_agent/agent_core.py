"""Central agent event loop, tool routing, and conversation orchestration.

Ties together `KimiClient`, `HardwareInterface`, and `ConversationMemory`
into the "HERMES Intelligence Unit" agent: a resilient async loop that
keeps running (and keeps local hardware state fresh) even through network
outages, retrying Kimi AI calls transparently and degrading gracefully to
local-only status reporting when the network is down.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

from loguru import logger

from hermes_agent.config import Settings
from hermes_agent.hardware_interface import HardwareError, HardwareInterface
from hermes_agent.kimi_client import KimiAPIError, KimiClient, KimiConnectionError
from hermes_agent.memory import ConversationMemory
from hermes_agent.tools import TOOL_SCHEMAS

SYSTEM_PROMPT_TEMPLATE = """\
You are the HERMES Intelligence Unit, an embedded AI agent running on a \
Raspberry Pi inside HERMES unit '{hermes_id}'. You have direct access to \
this unit's real sensors and outputs through function calls: reading \
system health (CPU, RAM, disk, temperature), reading digital telemetry \
(button, LED, relay state), driving digital outputs, and reading/writing \
a serial peripheral.

Operate conservatively: this hardware is physically real and may control \
equipment near people. Only trigger outputs when the request clearly \
calls for it, confirm ambiguous or destructive-sounding requests before \
acting, and always report the actual tool results back to the user \
rather than assuming success. If a tool call fails, explain the failure \
plainly and suggest a next step; do not silently retry indefinitely.

Keep responses concise -- they may be displayed on a small embedded \
screen or a log line."""


class ToolRouter:
    """Dispatches Kimi AI tool calls to the matching HardwareInterface coroutine, safely."""

    def __init__(self, hardware: HardwareInterface) -> None:
        self._dispatch = {
            "get_system_health": lambda **kw: hardware.get_system_health(),
            "read_telemetry": hardware.read_telemetry,
            "trigger_output": hardware.trigger_output,
            "serial_write": hardware.serial_write,
            "serial_read": hardware.serial_read,
        }

    async def execute(self, name: str, arguments_json: str) -> dict[str, Any]:
        if name not in self._dispatch:
            return {"error": f"Unknown tool: {name!r}"}
        try:
            kwargs = json.loads(arguments_json) if arguments_json else {}
            if not isinstance(kwargs, dict):
                raise ValueError("Tool arguments must decode to a JSON object")
        except (json.JSONDecodeError, ValueError) as exc:
            return {"error": f"Malformed tool arguments: {exc}"}

        try:
            result = await self._dispatch[name](**kwargs)
            return result
        except HardwareError as exc:
            logger.warning("Hardware error executing tool {!r}: {}", name, exc)
            return {"error": str(exc)}
        except TypeError as exc:
            logger.warning("Bad arguments for tool {!r}: {}", name, exc)
            return {"error": f"Invalid arguments for {name}: {exc}"}
        except Exception as exc:  # noqa: BLE001 - never let a tool crash the agent loop
            logger.exception("Unexpected error executing tool {!r}", name)
            return {"error": f"Unexpected error: {exc}"}


class HermesAgent:
    """The HERMES Intelligence Unit agent: owns the event loop and conversation flow."""

    def __init__(
        self,
        settings: Settings,
        kimi_client: KimiClient,
        hardware: HardwareInterface,
        memory: ConversationMemory,
    ) -> None:
        self._settings = settings
        self._kimi = kimi_client
        self._hardware = hardware
        self._memory = memory
        self._router = ToolRouter(hardware)
        self._system_prompt = SYSTEM_PROMPT_TEMPLATE.format(hermes_id=settings.hermes_id)
        self._network_degraded = False

    def _build_messages(self) -> list[dict[str, Any]]:
        history = self._memory.recent_messages()
        return [{"role": "system", "content": self._system_prompt}, *history]

    async def handle_user_message(self, text: str, on_delta: Any = None) -> str:
        """Process one user turn end-to-end: prompt -> Kimi -> tool loop -> final reply.

        Returns the assistant's final natural-language reply. Tool calls are
        executed and looped until Kimi stops requesting them or a safety
        cap on tool-call rounds is hit.
        """
        self._memory.append("user", text)

        max_tool_rounds = 6
        final_text = ""
        for _round in range(max_tool_rounds):
            messages = self._build_messages()
            try:
                result = await self._kimi.stream_chat_collecting(
                    messages, tools=TOOL_SCHEMAS, on_delta=on_delta
                )
                self._network_degraded = False
            except (KimiConnectionError, KimiAPIError) as exc:
                self._network_degraded = True
                logger.error("Kimi AI unavailable: {}", exc)
                return self._degraded_response(exc)

            if result.tool_calls:
                self._memory.append(
                    "assistant", result.content or None, tool_calls=result.tool_calls
                )
                for call in result.tool_calls:
                    fn = call["function"]
                    logger.info("Executing tool call: {}({})", fn["name"], fn["arguments"])
                    tool_result = await self._router.execute(fn["name"], fn["arguments"])
                    self._memory.append(
                        "tool",
                        json.dumps(tool_result),
                        tool_call_id=call["id"],
                    )
                continue  # loop back so Kimi can see tool results

            final_text = result.content
            self._memory.append("assistant", final_text)
            break
        else:
            logger.warning("Hit max tool-call rounds ({}) without a final answer", max_tool_rounds)
            final_text = final_text or (
                "I attempted several tool calls but couldn't reach a final answer. "
                "Please rephrase or try again."
            )

        return final_text

    def _degraded_response(self, exc: Exception) -> str:
        """Best-effort local status report when Kimi AI cannot be reached."""
        return (
            "I can't reach Kimi AI right now (network or API issue: "
            f"{exc}). HERMES unit '{self._settings.hermes_id}' hardware is still "
            "operating locally; I'll keep retrying in the background."
        )

    @property
    def network_degraded(self) -> bool:
        return self._network_degraded

    async def run_forever(self, input_queue: "asyncio.Queue[str]") -> None:
        """Main event loop: consumes user inputs, ticks hardware status on an interval.

        Runs two concurrent tasks: one draining `input_queue` for user
        messages, and one periodic tick that keeps local hardware state
        warm/logged even with no user interaction, so HERMES stays
        observable regardless of Kimi AI reachability.
        """
        await asyncio.gather(
            self._consume_inputs(input_queue),
            self._periodic_tick(),
        )

    async def _consume_inputs(self, input_queue: "asyncio.Queue[str]") -> None:
        while True:
            text = await input_queue.get()
            try:
                reply = await self.handle_user_message(text)
                logger.info("HERMES reply: {}", reply)
            except Exception:  # noqa: BLE001 - the loop must never die
                logger.exception("Unhandled error processing user message")
            finally:
                input_queue.task_done()

    async def _periodic_tick(self) -> None:
        while True:
            try:
                health = await self._hardware.get_system_health()
                level = "warning" if health["cpu_temp_celsius"] and health["cpu_temp_celsius"] > 75 else "debug"
                logger.log(level.upper(), "HERMES tick: {}", health)
            except Exception:  # noqa: BLE001 - a bad tick must not kill the loop
                logger.exception("Error during periodic hardware tick")
            await asyncio.sleep(self._settings.update_interval)
