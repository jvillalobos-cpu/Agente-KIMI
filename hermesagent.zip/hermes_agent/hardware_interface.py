"""Abstraction over Raspberry Pi hardware, exposed as Kimi AI tool calls.

On real Raspberry Pi hardware this drives GPIO pins and reads system
telemetry (CPU temperature, load, memory). On any other machine (dev
laptop, CI), it transparently falls back to a simulated backend so the
agent core can be developed and tested without physical hardware.
"""

from __future__ import annotations

import asyncio
import shutil
import time
from dataclasses import dataclass
from typing import Any

from loguru import logger

from hermes_agent.config import Settings

try:
    import RPi.GPIO as GPIO  # type: ignore[import-not-found]

    _HAS_GPIO = True
except (ImportError, RuntimeError):
    GPIO = None  # type: ignore[assignment]
    _HAS_GPIO = False

try:
    import serial  # type: ignore[import-not-found]

    _HAS_SERIAL = True
except ImportError:
    serial = None  # type: ignore[assignment]
    _HAS_SERIAL = False


@dataclass
class SystemHealth:
    cpu_percent: float
    cpu_temp_celsius: float | None
    ram_used_mb: float
    ram_total_mb: float
    disk_free_gb: float
    uptime_seconds: float


class HardwareError(RuntimeError):
    """Raised when a hardware operation fails (bad pin, serial I/O error, etc.)."""


class HardwareInterface:
    """Unified access point for HERMES sensors, actuators, and system metrics.

    Every public method here corresponds 1:1 to a Kimi AI tool/function
    schema in `agent_core.py`'s tool registry, so signatures and return
    shapes should stay JSON-serializable.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._simulate = settings.hardware_simulate or not _HAS_GPIO
        self._serial_conn: Any = None
        self._pin_state: dict[int, bool] = {}
        self._lock = asyncio.Lock()

        if self._simulate:
            logger.info("HardwareInterface running in SIMULATED mode (no real GPIO detected).")
        else:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            for pin in (
                settings.gpio.status_led,
                settings.gpio.alert_led,
                settings.gpio.relay_output,
            ):
                GPIO.setup(pin, GPIO.OUT, initial=GPIO.LOW)
            GPIO.setup(settings.gpio.button_input, GPIO.IN, pull_up_down=GPIO.PUD_UP)

        self._start_time = time.monotonic()

    def shutdown(self) -> None:
        """Release GPIO resources on process exit."""
        if not self._simulate and _HAS_GPIO:
            GPIO.cleanup()
        if self._serial_conn is not None:
            try:
                self._serial_conn.close()
            except Exception:  # noqa: BLE001 - best-effort cleanup
                logger.exception("Error closing serial connection during shutdown")

    # ------------------------------------------------------------------
    # Tool-callable methods
    # ------------------------------------------------------------------

    async def get_system_health(self) -> dict[str, Any]:
        """Return current CPU/RAM/disk/temperature/uptime metrics for the HERMES unit."""
        loop = asyncio.get_running_loop()
        health = await loop.run_in_executor(None, self._read_system_health)
        return {
            "cpu_percent": round(health.cpu_percent, 1),
            "cpu_temp_celsius": health.cpu_temp_celsius,
            "ram_used_mb": round(health.ram_used_mb, 1),
            "ram_total_mb": round(health.ram_total_mb, 1),
            "disk_free_gb": round(health.disk_free_gb, 2),
            "uptime_seconds": round(health.uptime_seconds, 1),
            "simulated": self._simulate,
        }

    async def read_telemetry(self, channel: str) -> dict[str, Any]:
        """Read a named telemetry channel: 'button' (digital input) or 'status_led'/'alert_led'/'relay_output' state."""
        async with self._lock:
            if channel == "button":
                value = await self._digital_read(self._settings.gpio.button_input)
                return {"channel": channel, "pressed": not value if not self._simulate else value}
            if channel in {"status_led", "alert_led", "relay_output"}:
                pin = getattr(self._settings.gpio, channel)
                return {"channel": channel, "on": self._pin_state.get(pin, False)}
            raise HardwareError(f"Unknown telemetry channel: {channel!r}")

    async def trigger_output(self, output: str, state: bool) -> dict[str, Any]:
        """Set a digital output ('status_led', 'alert_led', or 'relay_output') on or off."""
        if output not in {"status_led", "alert_led", "relay_output"}:
            raise HardwareError(f"Unknown output: {output!r}")
        pin = getattr(self._settings.gpio, output)
        async with self._lock:
            await self._digital_write(pin, state)
            self._pin_state[pin] = state
        logger.info("HERMES output {!r} (pin {}) set to {}", output, pin, state)
        return {"output": output, "pin": pin, "state": state, "simulated": self._simulate}

    async def serial_write(self, data: str) -> dict[str, Any]:
        """Write a line of text to the configured serial peripheral (e.g. an external sensor board)."""
        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(None, self._serial_write_sync, data)
        except Exception as exc:  # noqa: BLE001
            raise HardwareError(f"Serial write failed: {exc}") from exc
        return {"bytes_written": len(data.encode()), "simulated": not _HAS_SERIAL}

    async def serial_read(self, timeout_seconds: float = 1.0) -> dict[str, Any]:
        """Read one line from the configured serial peripheral, with a timeout."""
        loop = asyncio.get_running_loop()
        try:
            line = await loop.run_in_executor(None, self._serial_read_sync, timeout_seconds)
        except Exception as exc:  # noqa: BLE001
            raise HardwareError(f"Serial read failed: {exc}") from exc
        return {"line": line, "simulated": not _HAS_SERIAL}

    # ------------------------------------------------------------------
    # Internal sync helpers (run off the event loop thread)
    # ------------------------------------------------------------------

    def _read_system_health(self) -> SystemHealth:
        cpu_percent = self._read_cpu_percent()
        cpu_temp = self._read_cpu_temp()
        ram_used_mb, ram_total_mb = self._read_ram()
        disk_free_gb = shutil.disk_usage("/").free / (1024**3)
        uptime = time.monotonic() - self._start_time
        return SystemHealth(cpu_percent, cpu_temp, ram_used_mb, ram_total_mb, disk_free_gb, uptime)

    @staticmethod
    def _read_cpu_percent() -> float:
        try:
            with open("/proc/loadavg") as f:
                load1 = float(f.read().split()[0])
            import os

            cores = os.cpu_count() or 1
            return min(100.0, (load1 / cores) * 100.0)
        except (OSError, ValueError):
            return 0.0

    @staticmethod
    def _read_cpu_temp() -> float | None:
        try:
            with open("/sys/class/thermal/thermal_zone0/temp") as f:
                return int(f.read().strip()) / 1000.0
        except (OSError, ValueError):
            return None

    @staticmethod
    def _read_ram() -> tuple[float, float]:
        try:
            info: dict[str, int] = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    key, _, rest = line.partition(":")
                    value_kb = int(rest.strip().split()[0])
                    info[key] = value_kb
            total_kb = info.get("MemTotal", 0)
            available_kb = info.get("MemAvailable", 0)
            used_kb = max(0, total_kb - available_kb)
            return used_kb / 1024.0, total_kb / 1024.0
        except (OSError, ValueError, IndexError):
            return 0.0, 0.0

    async def _digital_write(self, pin: int, state: bool) -> None:
        if self._simulate:
            return
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, GPIO.output, pin, GPIO.HIGH if state else GPIO.LOW)

    async def _digital_read(self, pin: int) -> bool:
        if self._simulate:
            return False
        loop = asyncio.get_running_loop()
        value = await loop.run_in_executor(None, GPIO.input, pin)
        return bool(value)

    def _ensure_serial(self) -> Any:
        if not _HAS_SERIAL:
            return None
        if self._serial_conn is None:
            self._serial_conn = serial.Serial(
                self._settings.serial_port,
                self._settings.serial_baudrate,
                timeout=1.0,
            )
        return self._serial_conn

    def _serial_write_sync(self, data: str) -> None:
        conn = self._ensure_serial()
        if conn is None:
            logger.debug("Serial not available; simulated write of {!r}", data)
            return
        conn.write((data + "\n").encode())

    def _serial_read_sync(self, timeout_seconds: float) -> str | None:
        conn = self._ensure_serial()
        if conn is None:
            return None
        conn.timeout = timeout_seconds
        raw = conn.readline()
        return raw.decode(errors="replace").strip() or None
