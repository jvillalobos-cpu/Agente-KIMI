"""Strict, validated runtime configuration for the HERMES agent.

All settings are sourced from environment variables (optionally via a
`.env` file) and validated eagerly at process startup with pydantic v2 /
pydantic-settings so that a misconfigured HERMES unit fails fast instead of
crashing later mid-conversation.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class GPIOPinMap(BaseSettings):
    """Logical-to-physical GPIO pin assignments (BCM numbering) for the HERMES unit.

    Overridable individually via `HERMES_PIN_<NAME>` environment variables,
    e.g. `HERMES_PIN_STATUS_LED=27`.
    """

    model_config = SettingsConfigDict(env_prefix="HERMES_PIN_", extra="ignore")

    status_led: int = 17
    alert_led: int = 27
    relay_output: int = 22
    button_input: int = 23


class Settings(BaseSettings):
    """Top-level application settings, loaded once and shared read-only."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="",
        extra="ignore",
        case_sensitive=False,
    )

    # --- Kimi AI (Moonshot AI) ---
    kimi_api_key: SecretStr = Field(..., description="Moonshot AI API key.")
    kimi_base_url: str = Field(
        default="https://api.moonshot.cn/v1",
        description="Kimi AI OpenAI-compatible API base URL.",
    )
    kimi_model: str = Field(
        default="moonshot-v1-128k",
        description="Kimi model identifier (context-window variant).",
    )
    kimi_request_timeout: float = Field(default=60.0, gt=0)
    kimi_max_retries: int = Field(default=5, ge=0, le=20)
    kimi_backoff_base: float = Field(default=1.5, gt=0)
    kimi_backoff_max: float = Field(default=60.0, gt=0)

    # --- HERMES identity ---
    hermes_id: str = Field(..., min_length=1, description="Unique HERMES unit identifier.")
    log_level: str = Field(default="INFO")
    update_interval: float = Field(
        default=5.0, gt=0, description="Seconds between agent event-loop ticks."
    )

    # --- Storage ---
    data_dir: Path = Field(default=Path("/var/lib/hermes-agent"))
    conversation_db: Path = Field(default=Path("/var/lib/hermes-agent/conversation.sqlite3"))
    log_dir: Path = Field(default=Path("/var/log/hermes-agent"))

    # --- Agent memory ---
    history_window_messages: int = Field(
        default=40, ge=2, description="Max messages kept in the sliding-window context."
    )
    history_max_chars: int = Field(
        default=24_000, ge=1000, description="Soft character budget for history sent to Kimi."
    )

    # --- Hardware ---
    hardware_simulate: bool = Field(
        default=False,
        description="Force simulated hardware even when running on real Pi GPIO hardware.",
    )
    gpio: GPIOPinMap = Field(default_factory=GPIOPinMap)
    serial_port: str = Field(default="/dev/serial0")
    serial_baudrate: int = Field(default=115200, gt=0)

    @field_validator("log_level")
    @classmethod
    def _validate_log_level(cls, value: str) -> str:
        allowed = {"TRACE", "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = value.upper()
        if upper not in allowed:
            raise ValueError(f"log_level must be one of {sorted(allowed)}, got {value!r}")
        return upper

    def ensure_directories(self) -> None:
        """Create local storage directories if they do not yet exist."""
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.conversation_db.parent.mkdir(parents=True, exist_ok=True)
        self.log_dir.mkdir(parents=True, exist_ok=True)


_settings: Settings | None = None


def get_settings() -> Settings:
    """Return the process-wide cached Settings instance, loading it on first use."""
    global _settings
    if _settings is None:
        _settings = Settings()  # type: ignore[call-arg]
    return _settings
